# Rounded Icons — SVG

612 SVG outline asli dari FigCraft. Setiap berkas di `icons/` memakai viewBox 24 × 24, stroke 2, dan ujung serta sambungan bulat. `sprite.svg` menyediakan ID simbol seperti `icon-event-live`. `catalog.json` memetakan nama ke kategori.

Pasang tarball lokal dengan `npm install /path/to/rounded-icons-svg-0.1.0.tgz`, atau salin SVG langsung. Untuk mengubah warna lewat CSS, gunakan SVG inline atau sprite; `currentColor` tidak diwariskan oleh SVG yang ditampilkan melalui `<img>`.
