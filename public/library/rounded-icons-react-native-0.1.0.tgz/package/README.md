# Rounded Icons — React Native & Expo

```sh
npm install /path/to/rounded-icons-react-native-0.1.0.tgz
# Expo:
npx expo install react-native-svg
# React Native tanpa Expo, untuk versi RN yang kompatibel:
npm install react-native-svg@^15
```

Untuk React Native iOS tanpa Expo, pasang pods bila diperlukan (`npx pod-install`) dan build ulang aplikasi. Pilih versi `react-native-svg` yang cocok dengan versi React Native proyek; paket ini mendukung mayor 15.

```tsx
import { EventLive } from '@rounded-icons/react-native/icons/event-live';

<EventLive size={24} color="#1F5C4A" label="Siaran langsung" />
```

Hilangkan `label` untuk ikon dekoratif. Pada tema gelap, kirim warna dari tema karena default ikon native adalah tinta gelap.
