# Rounded Icons — React

Pasang dari tarball lokal: `npm install /path/to/rounded-icons-react-0.1.0.tgz`. Memerlukan React 18+. Semua 612 ikon punya ekspor TypeScript bernama dan jalur impor individual.

```tsx
import { EventLive } from '@rounded-icons/react/icons/event-live';

<EventLive size={24} color="currentColor" label="Siaran langsung" />
```

Hilangkan `label` jika ikon dekoratif atau teks tombol sudah memberi nama. SVG mewarisi warna teks secara default.
